kill $(cat /usr/local/gunicorn.pid)
